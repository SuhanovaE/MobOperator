﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MobileOperator.Classes;

namespace MobileOperator.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditAbonentsAndTarifsPage.xaml
    /// </summary>
    public partial class AddEditAbonentsAndTarifsPage : Page
    {
        private AbonentsAndTarifs _currentAbonentsAndTarifs = new AbonentsAndTarifs();

        public AddEditAbonentsAndTarifsPage(AbonentsAndTarifs selectedAbonentsAndTarifs)
        {
            InitializeComponent();
            if (selectedAbonentsAndTarifs != null)
                _currentAbonentsAndTarifs = selectedAbonentsAndTarifs;
   
            //создаем контекст
            DataContext = _currentAbonentsAndTarifs;

            CmbAbonents.ItemsSource = MobOperatorEntities.GetContext().Abonents.ToList();
            CmbAbonents.SelectedValuePath = "Id_Abonents";
            CmbAbonents.DisplayMemberPath = "LastName";

            CmbTarifs.ItemsSource = MobOperatorEntities.GetContext().Tarifs.ToList();
            CmbTarifs.SelectedValuePath = "Id_Tarifs";
            CmbTarifs.DisplayMemberPath = "Name";
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
           
            if (_currentAbonentsAndTarifs.Id_AbonentsAndTarifs == 0)
                MobOperatorEntities.GetContext().AbonentsAndTarifs.Add(_currentAbonentsAndTarifs); //добавить в контекст
            try
            {
                MobOperatorEntities.GetContext().SaveChanges(); 
                MessageBox.Show("Установление абоненту тариф выполнено");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString()); 
            }
        }
    }
}
