﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MobileOperator.Classes;

namespace MobileOperator.Pages
{
    /// <summary>
    /// Логика взаимодействия для AbonentsAndTarifsPage.xaml
    /// </summary>
    public partial class AbonentsAndTarifsPage : Page
    {
        public AbonentsAndTarifsPage()
        {
            InitializeComponent();
        }

        

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditAbonentsAndTarifsPage(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var abonentAndtarifForRemoving = DGridAbonentsAndTarifs.SelectedItems.Cast<AbonentsAndTarifs>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {abonentAndtarifForRemoving.Count()} данную связь?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    MobOperatorEntities.GetContext().AbonentsAndTarifs.RemoveRange(abonentAndtarifForRemoving);
                    MobOperatorEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridAbonentsAndTarifs.ItemsSource = MobOperatorEntities.GetContext().AbonentsAndTarifs.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            //редактирование
            ClassFrame.frmObj.Navigate(new AddEditAbonentsAndTarifsPage((sender as Button).DataContext as AbonentsAndTarifs));
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            //динамическое отображение данных или изменение данных
            if (Visibility == Visibility.Visible)
            {
                MobOperatorEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridAbonentsAndTarifs.ItemsSource = MobOperatorEntities.GetContext().AbonentsAndTarifs.ToList();
            }
        }

        private void BtnNum_Click(object sender, RoutedEventArgs e)
        {
            int countRow = DGridAbonentsAndTarifs.Items.Count;
            TxtNum.Text = countRow.ToString();
        }
    }
}
