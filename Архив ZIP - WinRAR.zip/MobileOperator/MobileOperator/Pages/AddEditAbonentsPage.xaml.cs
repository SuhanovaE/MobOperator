﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MobileOperator.Pages;
using MobileOperator.Classes; 


namespace MobileOperator.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditAbonentsPage.xaml
    /// </summary>
    public partial class AddEditAbonentsPage : Page
    {
        private Abonents _currentAbonents = new Abonents();

        public AddEditAbonentsPage(Abonents selectedAbonents)
        {
            InitializeComponent();
            if (selectedAbonents != null)
                _currentAbonents = selectedAbonents;
            //создаем контекст
            DataContext = _currentAbonents;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentAbonents.LastName))
                error.AppendLine("Укажите название");
            
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //если пользователь новый
            if (_currentAbonents.Id_Abonents == 0)
                MobOperatorEntities.GetContext().Abonents.Add(_currentAbonents); //добавить в контекст
            try
            {
                MobOperatorEntities.GetContext().SaveChanges(); // сохраняет все изменения
                MessageBox.Show("Новый клиент добавлен");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString()); //сообщение об ошибке
            }
        }

    }
}
